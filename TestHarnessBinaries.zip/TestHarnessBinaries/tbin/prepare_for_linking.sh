ghc -v -keep-tmp-files -tmpdir=./tmp --make -i.. ${1} 2>&1
